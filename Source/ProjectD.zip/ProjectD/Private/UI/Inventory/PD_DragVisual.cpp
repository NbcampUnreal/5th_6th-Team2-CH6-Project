﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Inventory/PD_DragVisual.h"
#include "Components/TextBlock.h"

void UPD_DragVisual::SetActionText(const FString& NewText, bool bVisible)
{
    if (ActionText)
    {
        ActionText->SetText(FText::FromString(NewText));
        ActionText->SetVisibility(bVisible ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
    }
}